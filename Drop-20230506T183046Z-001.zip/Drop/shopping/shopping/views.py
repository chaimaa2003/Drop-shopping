from django.http import HttpResponse

def home(request):
	st="H E L L O"
	return HttpResponse(st)
