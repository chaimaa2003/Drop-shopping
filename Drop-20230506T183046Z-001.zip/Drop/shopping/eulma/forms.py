from django.forms import ModelForm
from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Sailler,DropShop,Custumer,Bool



class CreateNewUser(UserCreationForm):
	class Meta:
		model=User
		fields=['username']




class SaillerForm(forms.ModelForm):
	class Meta:
		model=Sailler
		fields="__all__"




class DropShopForm(forms.ModelForm):
	class Meta:
		model=DropShop
		fields="__all__"






class CustumerForm(forms.ModelForm):
	class Meta:
		model=Custumer
		fields="__all__"



class BoolForm(forms.ModelForm):
	class Meta:
		model=Bool
		fields="__all__"