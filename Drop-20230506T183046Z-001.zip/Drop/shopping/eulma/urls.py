from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('userLogin/',views.userLogin,name='userLogin'),
    path('register/',views.register,name='register'),
    
    
    path('userLogout/',views.userLogout,name='userLogout'),
    path('sailler/',views.sailler,name='saillerpage'),
    path('dropshop/',views.dropshop,name='dropshop'),
    path('saillers_list/',views.saillers_list,name='saillers_list'),
    path('custumer/',views.custumer,name='custumer'),
    path('dashboard/',views.dashboard,name='dashboard'),
    path('create/',views.create,name='create'),
    path('delete/',views.delete,name='delete'),
    path('custumers_list/',views.custumers_list,name='custumers_list'),
    path('bool/',views.bool,name='bool'),
   

    

    

   


     
    
    
]
