from django.contrib import admin
from .models import Sailler,DropShop,Custumer

admin.site.register(Sailler)

admin.site.register(DropShop)


admin.site.register(Custumer)