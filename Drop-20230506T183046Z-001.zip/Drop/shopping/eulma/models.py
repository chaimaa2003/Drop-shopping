from django.db import models





class Sailler(models.Model):

	Full_Name=models.CharField(max_length=50,null=True,blank=True)
	
	
	Home_adress=models.CharField(max_length=50,null=True,blank=True)
	Email=models.EmailField(max_length=50,null=True,blank=True)
	Phone_number=models.IntegerField(default=None,null=True,blank=True)
	Wilaya=models.CharField(max_length=50,null=True,blank=True)
	Municipal=models.CharField(max_length=50,null=True,blank=True)
	ccp=models.IntegerField(default=None,null=True,blank=True)
	def __str__(self):
		return self.Full_Name

	








class DropShop(models.Model):
	product=models.CharField(max_length=50,null=True,blank=True)
	price=models.FloatField(default=0.0,null=True,blank=True)
	quantity=models.IntegerField(default=0,null=True,blank=True)
	sailler=models.ForeignKey(Sailler,on_delete=models.CASCADE,null=False)
	montant=models.FloatField(default=0.0,null=True,blank=True)
	
	updatetime=models.DateTimeField(auto_now_add=True,null=True,blank=True)







class Custumer(models.Model):
	Full_Name=models.CharField(max_length=50,null=True,blank=True)
	
	adress=models.CharField(max_length=50,null=True,blank=True)
	Municipal=models.CharField(max_length=50,null=True,blank=True)
	Phone_Number=models.IntegerField(default=None,null=True,blank=True)
	Age=models.IntegerField(default=None,null=True,blank=True)
	email=models.EmailField(max_length=50,null=True,blank=True)
	Purchased_product=models.CharField(max_length=50,null=True,blank=True)


class Bool(models.Model):
	paye=models.BooleanField(default=False,null=True,blank=True)




form=PortForm_1()
	if request.method=='POST':
		form=PortForm_1(request.POST)
		if form.is_valid():
			form.save()
			return JsonResponse('wallet selected sucessfuly')
		else:
			form=PortForm_1()

	context={"form":form}
	return render(request,"exchange/before_exchange.html",context)



const selection=document.getElementById('you');
selection.addEventListener('change',()=>{
  const xhr=new new XMLHttpRequest();
  xhr.open('POST','/give_port/');

  


xhr.setRequestHeader('Content-Type','application/json');
xhr.setRequestHeader('X-CSRFToken',getCookie('csrftoken'));
xhr.onload=()=>{
  const response=JSON.parse(xhr.responseText);
  if(response.success){
    console.log('Data successfully submitted');

  }
  else{
    console.error('Error submitting data');
  }

  
};
xhr.send(JSON.stringify({selection:selection.value}));
});


const selection=document.getElementById('you');
selection.addEventListener('change',()=>{
  const xhr=new new XMLHttpRequest();
  xhr.open('POST','/give_port/');

  


xhr.setRequestHeader('Content-Type','application/json');
xhr.setRequestHeader('X-CSRFToken',getCookie('csrftoken'));
xhr.onload=()=>{
  const response=JSON.parse(xhr.responseText);
  if(response.success){
    console.log('Data successfully submitted');

  }
  else{
    console.error('Error submitting data');
  }

  
};
xhr.send(JSON.stringify({selection:selection.value}));
});


