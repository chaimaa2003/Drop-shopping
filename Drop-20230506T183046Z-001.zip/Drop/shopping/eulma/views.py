from django.shortcuts import render,redirect
from .forms import CreateNewUser,SaillerForm,DropShopForm,CustumerForm,BoolForm
from .models import Sailler,DropShop,Custumer,Bool
from django.contrib.auth import authenticate,login,logout
from django.core.exceptions import ValidationError
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.decorators import user_passes_test
from django.contrib.auth.models import Group
from django.views.decorators.csrf import csrf_protect,csrf_exempt
from django.core.validators import validate_email
from django.http import JsonResponse,HttpResponse
from django.views.decorators.cache import never_cache

from django.core.paginator import Paginator
















def is_admin(user):
	 return user.is_authenticated and user.is_superuser








@csrf_protect
@csrf_exempt
def register(request):
	form=CreateNewUser()
	if request.method=='POST':
		form=CreateNewUser(request.POST)
		if form.is_valid():
			form.save()
			
			
			user=form.cleaned_data.get('username')
			
			
			return redirect('userLogin')
		else:
			messages.info(request,"your register process has failed")
	context={"form":form}
	

	return render(request,"eulma/register.html",context)





@csrf_protect
@csrf_exempt
def userLogin(request):
	
	if request.method=='POST':
		username=request.POST.get('username')
		password=request.POST.get('password')

		
		user=authenticate(request,username=username,password=password)
		if user is not None:
			login(request,user)
			if user.is_superuser:
				return redirect('dropshop')
			else:
				return redirect('custumer')
		else:
			messages.info(request,"sign in was failed")

  			

	    	
		
	context={}

				
	    
	

	return render(request,"eulma/userLogin.html",context)




def userLogout(request):
   
    logout(request)
    return redirect('userLogin')


    
@csrf_protect
@csrf_exempt
@login_required(login_url='userLogin')   	
def sailler(request):
	if request.method=="POST":
		

		Full_Name=request.POST.get('Full_Name')
		Home_adress=request.POST.get('Home_adress')
		Email=request.POST.get('Email')
		Phone_number=request.POST.get('Phone_number')
		Wilaya=request.POST.get('Wilaya')
		ccp=request.POST.get('ccp')
		Municipal=request.POST.get('Municipal')
		my=Sailler(email=email,wallet=wallet,coupon=coupon)
		my.save()
		return HttpResponse('sucessfuly')
	else:
		return render(request,"eulma/saillerform.html")

	

@csrf_protect
@csrf_exempt
@login_required(login_url='userLogin')   	
def bool(request):
	form=BoolForm()
	if request.method=='POST':
		form=BoolForm(request.POST)
		if form.is_valid():
			form.save()
			return JsonResponse('your are edited sucessfuly')
	else:
		form=BoolForm()

			
		

	return render(request,"eulma/saillerform.html",context)







@csrf_protect
@csrf_exempt
@login_required(login_url='userLogin')   	
def dropshop(request):
	form=DropShopForm()
	if request.method=='POST':
		form=DropShopForm(request.POST)
		if form.is_valid():
			form.save()
	else:
		form=DropShopForm()
	context={"form":form}

			

		
	

	return render(request,"eulma/dropshopform.html",context)




@csrf_protect
@csrf_exempt
@login_required(login_url='userLogin')   	
def custumer(request):
	if request.method=="POST":
		

		Full_Name=request.POST.get('Full_Name')
		adress=request.POST.get('adress')
		email=request.POST.get('email')
		Phone_Number=request.POST.get('Phone_Number')
		Wilaya=request.POST.get('Wilaya')
		Purchased_product=request.POST.get('Purchased_product')
		Municipal=request.POST.get('Municipal')
		my=Custumer(email=email,wallet=wallet,coupon=coupon)
		my.save()
		return HttpResponse('sucessfuly')
	else:
		return render(request,"eulma/custumerform.html")

	

@login_required(login_url='userLogin')

@user_passes_test(is_admin)
def saillers_list(request):
	saillers=Sailler.objects.all()
	number_of_saillers=saillers.count()
	p=Paginator(Custumer.objects.all(),6)
	page=request.GET.get('page')
	pages=p.get_page(page)
	
	context={"saillers":saillers,"number_of_saillers":number_of_saillers,"pages":pages}
	return render(request,"eulma/saillers_list.html",context)
	

	
		

	
	

	

@never_cache
@login_required(login_url='userLogin')
@user_passes_test(is_admin)
def dashboard(request):
	drop_shoppers=DropShop.objects.all()
	number_of_drop_shoppers=drop_shoppers.count()
	p=Paginator(Custumer.objects.all(),6)
	page=request.GET.get('page')
	pages=p.get_page(page)
	context={"drop_shoppers":drop_shoppers,"number_of_drop_shoppers":number_of_drop_shoppers,"pages":pages}
	return render(request,"eulma/dashboard.html",context)

@login_required(login_url='userLogin')
@user_passes_test(is_admin)
def custumers_list(request):
	custumers=custumer.objects.all()
	number_of_custumers=custumers.count()
	p=Paginator(Custumer.objects.all(),6)
	page=request.GET.get('page')
	pages=p.get_page(page)
	context={"custumers":custumers,"number_of_custumers":number_of_custumers,"pages":pages}
	return render(request,"eulma/custumers_list.html",context)



@csrf_protect
@csrf_exempt
@login_required(login_url='userLogin')


def create(request):
	
	form=OrderForm()
	if request.method=='POST':
		form=OrderForm(request.POST)
		if form.is_valid():
			form.save()
			return redirect('dashboard')
	context={"form":form}
	return render(request,"eulma/my_orderform.html",context)
@csrf_protect
@csrf_exempt
@login_required(login_url='userLogin')

def update(request,pk):
	order=Order.objects.get(id=pk)
	form=OrderForm(instance=order)
	if request.method=='POST':
		form=OrderForm(request.POST,instance=order)
		if form.is_valid():
			form.save()
			return redirect('/')
	context={"form":form}
	return render(request,"eulma/my_orderform.html",context)

@csrf_protect
@csrf_exempt
@login_required(login_url='userLogin')

def delete(request,pk):
	order=DropShop.objects.get(id=pk)
	if request.method=='POST':
		order.delete()
		return redirect('dashboard')
	context={"order":order}
	return render(request,"eulma/my_delete.html",context)












